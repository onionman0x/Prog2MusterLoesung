#include <iostream>
#include "cZeichenKlon.h"
#include <string>

using namespace std;

cZeichenKlon::cZeichenKlon(char zeichen_in, int anzahlKlone_in) : zeichen(zeichen_in), anzahlKlone(anzahlKlone_in)
{
}

void cZeichenKlon::ausgabe()
{
	std::cout << "Zeichen : " << zeichen << std::endl;
	std::cout << "Anzahl Klone: " << anzahlKlone << std::endl;
}

void cZeichenKlon::operator++(int)
{
	anzahlKlone++;
}

void cZeichenKlon::operator--(int)
{
	if (anzahlKlone > 0)
		anzahlKlone--;
}

ostream& operator<<(ostream& o, cZeichenKlon& c)
{
	o << "Zeichen : " << c.zeichen << endl;
	o << "Klone : ";
	if (c.anzahlKlone == 0) {
		o << "keine Klone";
	}
	else {
		for (int i = 0; i < c.anzahlKlone; i++) {
			o << c.zeichen << " ";
		}
	}
	o << endl;
	return o;
}

istream& operator>>(istream& i, cZeichenKlon& c)
{
	string tmp;
	char c_tmp;
	cout << "Zeichen eingeben : " << endl;
	i >> tmp;

	c_tmp = tmp.at(0);

	for (int n = 1; n < tmp.length(); n++) {
		if (tmp.at(n) != c_tmp)
			return i;
	}

	c.zeichen = c_tmp;
	c.anzahlKlone = tmp.length() - 1;
	return i;
}
