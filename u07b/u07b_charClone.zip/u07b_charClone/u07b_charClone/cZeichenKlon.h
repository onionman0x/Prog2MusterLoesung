#pragma once
#include <iostream>

using namespace std;

class cZeichenKlon
{
private:
	char zeichen;
	int anzahlKlone;

	friend ostream& operator << (ostream& o, cZeichenKlon& c);
	friend istream& operator >> (istream& i, cZeichenKlon& c);

public:
	cZeichenKlon(char zeichen_in = '%', int anzahlKlone_in = 0);
	void ausgabe();

	void operator ++ (int);
	void operator -- (int);
};

