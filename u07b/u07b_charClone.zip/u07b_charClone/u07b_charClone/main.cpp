#include "cZeichenKlon.h"
#include <iostream>

int main() {

	cZeichenKlon k1;

	k1.ausgabe();
	cout << k1;
	k1--;
	k1--;
	k1--;
	cout << k1;
	cin >> k1;
	k1.ausgabe();
	cout << k1;
	k1++;
	k1++;
	cout << k1;

	return 0;
}