#include "cSpielballon.h"

cSpielballon::cSpielballon(double hoehe_in, double volumen_in) : cBallon(hoehe_in, volumen_in)
{
}
