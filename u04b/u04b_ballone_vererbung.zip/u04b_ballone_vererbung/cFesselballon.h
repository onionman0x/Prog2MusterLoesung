#pragma once
#include "cFahrballon.h"
class cFesselballon :
    public cFahrballon
{
    double gasMenge;
public:
    cFesselballon(double gasMenge_in = 250.0, double hoehe_in = 200.0, double volumen_in = 120000.0, int fahrgaeste_in = 3);
    double gas_zugeben(double helium_kg);
    double gas_ablassen(double heliumraus);
};

