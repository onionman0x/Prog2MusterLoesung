#include "cBallon.h"

cBallon::cBallon(double hoehe_in, double volumen_in)
{
	hoehe = hoehe_in;
	volumen = volumen_in;
}

double cBallon::get_volumen()
{
	return volumen;
}

double cBallon::get_hoehe()
{
	return hoehe;
}

void cBallon::set_volumen(double v)
{
	volumen = v;
}

void cBallon::set_hoehe(double h)
{
	hoehe = h;
}

double cBallon::anschwellen(double zunahme)
{
	return volumen += zunahme;
}

double cBallon::schrumpfen(double abnahme)
{
	if((volumen - abnahme) >= 0.0)
		return volumen -= abnahme;
	return 0.0;
}

double cBallon::steigen(double rauf)
{
	return hoehe += rauf;
}

double cBallon::sinken(double runter)
{
	if((hoehe - runter) >= 0.0)
		return hoehe -= runter;
	return 0.0;
}
