#pragma once
#include "cBallon.h"
class cFahrballon :
    public cBallon
{
    int fahrgaeste;
public:
    cFahrballon(int fahrgaeste_in = 4, double hoehe_in = 200.0, double volumen_in = 100000.0);
    int get_fahrgaeste();
    int einsteigen(int rein);
    int aussteigen(int raus);
};

