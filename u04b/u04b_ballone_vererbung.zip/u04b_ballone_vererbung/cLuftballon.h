#pragma once
#include "cSpielballon.h"
#include <string>

enum Farben { rot, gruen, blau, gelb };

class cLuftballon :
    public cSpielballon
{
    Farben farbe;
public:
    cLuftballon(Farben farbe_in = blau, double hoehe_in = 1.8, double volumen_in = 1.9);
    void print_farbe();
};

