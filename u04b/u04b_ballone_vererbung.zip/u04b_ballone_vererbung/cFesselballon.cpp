#include "cFesselballon.h"

cFesselballon::cFesselballon(double gasMenge_in, double hoehe_in, double volumen_in, int fahrgaeste_in) : cFahrballon(fahrgaeste_in, hoehe_in, volumen_in)
{
	gasMenge = gasMenge_in;
}

double cFesselballon::gas_zugeben(double helium_kg)
{
	if (helium_kg > gasMenge)
		helium_kg = gasMenge;

	gasMenge -= helium_kg;
	cBallon::set_volumen(cBallon::get_volumen() + 5000 * helium_kg);
	cBallon::set_hoehe(cBallon::get_hoehe() + 5.0 * helium_kg);
	return gasMenge;
}

double cFesselballon::gas_ablassen(double heliumraus)
{
	cBallon::set_hoehe(cBallon::get_hoehe() - 0.01 * heliumraus);
	cBallon::set_volumen(cBallon::get_volumen() - heliumraus);
	return gasMenge;
}
