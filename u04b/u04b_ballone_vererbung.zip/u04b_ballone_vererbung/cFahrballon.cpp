#include "cFahrballon.h"

cFahrballon::cFahrballon(int fahrgaeste_in, double hoehe_in, double volumen_in) : cBallon(hoehe_in, volumen_in)
{
	fahrgaeste = fahrgaeste_in;
}

int cFahrballon::get_fahrgaeste()
{
	return fahrgaeste;
}

int cFahrballon::einsteigen(int rein)
{
	return fahrgaeste += rein;
}

int cFahrballon::aussteigen(int raus)
{
	if((fahrgaeste - raus) >= 0)
		return fahrgaeste -= raus;
	return 0;
}
