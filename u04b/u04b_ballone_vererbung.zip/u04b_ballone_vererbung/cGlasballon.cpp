#include "cGlasballon.h"

cGlasballon::cGlasballon(double hoehe_in, double volumen_in) : cSpielballon(hoehe_in, volumen_in)
{
}

double cGlasballon::anschwellen(double zunahme)
{
    return cBallon::get_volumen() + zunahme;
}

double cGlasballon::schrumpfen(double abnahme)
{
    return cBallon::get_volumen() - abnahme;
}

double cGlasballon::steigen(double rauf)
{
    return cBallon::get_hoehe() + rauf;
}

double cGlasballon::sinken(double runter)
{
    return cBallon::get_hoehe() - runter;
}
