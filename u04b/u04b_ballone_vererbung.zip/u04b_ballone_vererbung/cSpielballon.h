#pragma once
#include "cBallon.h"
class cSpielballon :
    public cBallon
{
public:
    cSpielballon(double hoehe_in = 1.5, double volumen_in = 2.5);
};

