#include "cHeissluftballon.h"

cHeissluftballon::cHeissluftballon(double luftTemp_in, int fahrgaeste_in, double hoehe_in, double volumen_in) : cFahrballon(fahrgaeste_in, hoehe_in, volumen_in)
{
	luftTemp = luftTemp_in;
}

double cHeissluftballon::luft_heizen(double hitzeplus)
{
	cBallon::set_volumen(cBallon::get_volumen() + 12.5 * hitzeplus);
	cBallon::set_hoehe(cBallon::get_hoehe() + 8.0 * hitzeplus);
	return luftTemp += hitzeplus;
}

double cHeissluftballon::luft_abkuehlen(double hitzeminus)
{
	cBallon::set_volumen(cBallon::get_volumen() - 12.5 * hitzeminus);
	cBallon::set_hoehe(cBallon::get_hoehe() - 8.0 * hitzeminus);
	return luftTemp -= hitzeminus;
}
