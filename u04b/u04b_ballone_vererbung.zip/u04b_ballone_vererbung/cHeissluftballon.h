#pragma once
#include "cFahrballon.h"
class cHeissluftballon :
    public cFahrballon
{
    double luftTemp;
public:
    cHeissluftballon(double luftTemp_in = 175.0, int fahrgaeste_in = 6, double hoehe_in = 200.0, double volumen_in = 80000.0);
    double luft_heizen(double hitzeplus);
    double luft_abkuehlen(double hitzeminus);
};


