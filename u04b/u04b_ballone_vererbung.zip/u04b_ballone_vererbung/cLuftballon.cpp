#include "cLuftballon.h"
#include <string>
#include <iostream>

cLuftballon::cLuftballon(Farben farbe_in, double hoehe_in, double volumen_in) : cSpielballon(hoehe_in, volumen_in)
{
	farbe = farbe_in;
}

void cLuftballon::print_farbe()
{
	std::string color = "";
	switch (farbe) {
		case blau: 
			color = "blau";
			break;
		case rot:
			color = "rot";
			break;
		case gruen:
			color = "gruen";
			break;
		case gelb:
			color = "gelb";
			break;
	}
	std::cout << "Die Frabe des Luftballons ist " << color << std::endl;
}
