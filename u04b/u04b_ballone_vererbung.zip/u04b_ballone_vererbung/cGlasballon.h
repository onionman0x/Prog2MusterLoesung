#pragma once
#include "cSpielballon.h"
class cGlasballon :
    public cSpielballon
{
public:
    cGlasballon(double hoehe_in = 0.0, double volumen_in = 13.0);
    double anschwellen(double zunahme);
    double schrumpfen(double abnahme);
    double steigen(double rauf);
    double sinken(double runter);
};

