#include "cFesselballon.h"
#include "cHeissluftballon.h"
#include "cGlasballon.h"
#include "cLuftballon.h"
#include <iostream>

using namespace std;

int main() {

	cFesselballon Lucky7;
	cHeissluftballon Abendfahrt(7);
	cGlasballon Goldfischbecken(0.8, 11.5);
	cLuftballon Kinderfreude;

	cout << "Fesselballon Lucky7 hat Fahrgaeste: " << Lucky7.get_fahrgaeste() << endl; 
	cout << "Nach einsteigen(3): " << Lucky7.einsteigen(3) << endl; 
	cout << "Nach aussteigen(4): " << Lucky7.aussteigen(4) << endl; 
	cout << "Starthoehe: " << Lucky7.get_hoehe() << endl; 
	cout << "Startvolumen: " << Lucky7.get_volumen() << endl; 
	cout << "Startgasmenge: " << Lucky7.gas_zugeben(0.0) << endl; 
	cout << "Fluessiggasrest nach gas_zugeben() 3,5 kg: " << Lucky7.gas_zugeben(3.5) << endl; 
	cout << "Volumen jetzt: " << Lucky7.get_volumen() << endl; 
	cout << "Hoehe derzeit: " << Lucky7.get_hoehe() << endl; 
	cout << "Anstieg wegen Thermik um 23 m auf: " << Lucky7.steigen(23.0) << endl; 
	cout << "Hoehe derzeit: " << Lucky7.get_hoehe() << endl; 
	cout << "Gasablassen 50.0: " << Lucky7.gas_ablassen(1500.0) << endl; 
	cout << "Volumen jetzt: " << Lucky7.get_volumen() << endl; 
	cout << "Hoehe derzeit: " << Lucky7.get_hoehe() << endl; 
	cout << endl;
	
	// Mit dem Heissluftballon fahren
	cout << "Heissluftballon Abendfahrt: Starthoehe: " << Abendfahrt.get_hoehe() << endl;
	cout << "Startvolumen: " << Abendfahrt.get_volumen() << endl;
	cout << "Starttemperatur: " << Abendfahrt.luft_heizen(0.0) << endl;
	cout << "Temperatur nach aufheizen um 6 Grad: " << Abendfahrt.luft_heizen (6.0)<< endl;
	cout << "Volumen jetzt: " << Abendfahrt.get_volumen() << endl;
	cout << "Hoehe derzeit: " << Abendfahrt.get_hoehe() << endl;
	cout << "Anstieg wegen Thermik um 23 m auf: " << Abendfahrt.steigen(23.0) << endl;
	cout << "Hoehe derzeit: " << Abendfahrt.get_hoehe() << endl;
	cout << "Abkuehlung um 11 Grad: " << Abendfahrt.luft_abkuehlen(11.0) << endl;
	cout << "Volumen jetzt: " << Abendfahrt.get_volumen() << endl;
	cout << "Hoehe derzeit: " << Abendfahrt.get_hoehe() << endl;
	cout << endl;

	// Mit dem Luftballon spielen
	cout << "Luftballon Kinderfreude: ";
	Kinderfreude.print_farbe();

	cout << "Steigt nun auf: " << Kinderfreude.steigen(3.30) << endl;
	cout << "Sinkt nun wieder auf: " << Kinderfreude.sinken(4.10) << endl;
	cout << endl;
	
	// Den Glasballon manipulieren
	cout << "Goldfischbecken 44.4 m steigen lassen: " << Goldfischbecken.steigen(44.4) <<endl;
	cout << "Goldfischbecken um 30 Liter anschwellen lassen: "<< Goldfischbecken.anschwellen(30.0) << endl;
	cout << endl;

	return 0;
}