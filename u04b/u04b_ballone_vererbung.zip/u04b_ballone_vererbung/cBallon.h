#pragma once
class cBallon
{
	double hoehe;
	double volumen;
public:
	cBallon(double hoehe_in = 0.0, double volumen_in = 0.0);
	double get_volumen();
	double get_hoehe();
	void set_volumen(double v);
	void set_hoehe(double h);
	double anschwellen(double zunahme);
	double schrumpfen(double abnahme);
	double steigen(double rauf);
	double sinken(double runter);
};

