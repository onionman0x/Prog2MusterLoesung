#include "cBruch.h"
#include <iostream>

void tausch(cBruch* a, cBruch* b) {
	cBruch help;
	help = *a;
	*a = *b;
	*b = help;
}

void sortier(cBruch brueche[], int anzElement) {
	for (int n = anzElement; n > 1; n--) {
		for (int i = 0; i < n - 1; i++) {
			/*if (vergleich(brueche[i], brueche[i+1]) == -1) {
				tausch(brueche + i, brueche + (i+1));
			}*/
			if (brueche[i] > brueche[i + 1]) {
				tausch(brueche + i, brueche + (i + 1));
			}
		}
	}
}

int main() {
	cBruch ergebnis;
	cBruch brueche[8] = {
		cBruch(3,6), cBruch(21,-7), cBruch(8,-10), cBruch(-4,6), cBruch(-8,13), cBruch(-4,5), cBruch(21,37)
	};

	std::cout << "Brueche: " << std::endl;

	for (int i = 0; i < 8; i++) {
		brueche[i].ausgabe();
	}

	std::cout << std::endl << "Berechnungen: " << std::endl;

	ergebnis = add(brueche[0], brueche[1]);
	ergebnis.ausgabe();

	ergebnis = sub(brueche[2], brueche[3]);
	ergebnis.ausgabe();

	ergebnis = mul(brueche[4], brueche[5]);
	ergebnis.ausgabe();

	ergebnis = div(brueche[6], brueche[7]);
	ergebnis.ausgabe();

	sortier(brueche, 8);

	std::cout << std::endl << "Brueche nach sortierung: " << std::endl;

	for (int i = 0; i < 8; i++) {
		brueche[i].ausgabe();
	}

	return 0;
}