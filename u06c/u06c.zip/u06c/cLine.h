#include <iostream>

using namespace std;

class cLine
{
private:
    string zeile;
    cLine *prev;

public:
    cLine(string zeile_in, cLine *prev_in);
    ~cLine();

    cLine* getPrev();
    string getLine();
    void setLine(string line_in);

    cLine* getNFromThis(int n, int *summ, int i);
    
    cLine* addElem(string zeile_in);
    void ausgabeLine();
};