#include <string.h>
#include "cText.h"

cLine* cText::parce_file(string filename)
{
    string line;

    ifstream in_file(filename);

    getline (in_file, line);
    cLine *curr = new cLine(line, nullptr);

    while (getline (in_file, line)) {
        curr = curr->addElem(line);
    }

    in_file.close();

    return curr;
}

cText::cText(string bezeichnung_in, string filename)
{
    bezeichnung = bezeichnung_in;
    text = parce_file(filename);
}

cText::~cText()
{
    if (text)
    {
        delete text;
    }
}

void cText::ausgabe()
{
    cout << "Bezeichnung: " << bezeichnung << endl;

    text->ausgabeLine();

    cout << endl;
}
void cText::ersetzeZeile(int num, string neuText)
{
    int summ = 0;
    cLine *curr = text->getNFromThis(num, &summ, 0);

    curr->setLine(neuText);
}
void cText::aendereBezeichnung(string neuBez)
{
    bezeichnung = neuBez;
}