#include <iostream>
#include "cText.h"

using namespace std;

int main()
{
    cText spielText("Rohtext", "data");

    spielText.ausgabe();

    spielText.aendereBezeichnung("Gedicht");

    spielText.ersetzeZeile(5, "als fuenftes ist‘s mir einerlei");

    spielText.ausgabe();

    return 0;
}