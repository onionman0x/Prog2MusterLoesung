#include "cKompRat.h"
#include "cBruch.h"

int main() {

	cKompRat helpMe;
	cKompRat komplexeZahlen[4] = {
		cKompRat(cBruch(21,56), cBruch(3,4)),
		cKompRat(cBruch(24,-6), cBruch(5,3)),
		cKompRat(cBruch(-8, 13), cBruch(7, -11))
	};

	for (int i = 0; i < 4; i++) {
		komplexeZahlen[i].ausgabe();
	}

	helpMe = add(komplexeZahlen[0], komplexeZahlen[1]);
	helpMe.ausgabe();

	helpMe = sub(komplexeZahlen[2], komplexeZahlen[3]);
	helpMe.ausgabe();

	helpMe = sub(komplexeZahlen[1], komplexeZahlen[2]);
	helpMe.ausgabe();

	return 0;
}