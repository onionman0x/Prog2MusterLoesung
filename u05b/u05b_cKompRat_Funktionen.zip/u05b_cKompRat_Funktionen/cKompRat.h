#pragma once

#include "cBruch.h"

class cKompRat
{
	cBruch r;
	cBruch i;

	friend cKompRat add(cKompRat k1, cKompRat k2);
	friend cKompRat sub(cKompRat k1, cKompRat k2);

public:
	cKompRat(cBruch r_in = cBruch(), cBruch i_in = cBruch());
	int kompRatVergleich(cKompRat lhs, cKompRat rhs);
	void ausgabe();
};

