#include "cKompRat.h"
#include <iostream>
#include <math.h>

cKompRat::cKompRat(cBruch r_in, cBruch i_in) : r(r_in), i(i_in)
{
}

int cKompRat::kompRatVergleich(cKompRat lhs, cKompRat rhs)
{
	float lhsValue = sqrt(pow(lhs.r.floatingNumber(), 2) + pow(lhs.r.floatingNumber(), 2));
	float rhsValue = sqrt(pow(rhs.r.floatingNumber(), 2) + pow(rhs.r.floatingNumber(), 2));

	if (lhsValue > rhsValue)
		return -1;
	else if (lhsValue < rhsValue)
		return 1;
	else
		return 0;
}

void cKompRat::ausgabe()
{
	std::cout << "reeler Teil : ";
	r.ausgabe();
	std::cout << "imaginaerer Teil: ";
	i.ausgabe();
}

cKompRat add(cKompRat k1, cKompRat k2)
{
	cBruch r = add(k1.r, k2.r);
	cBruch i = add(k1.i, k2.i);
	return cKompRat(r, i);
}

cKompRat sub(cKompRat k1, cKompRat k2)
{
	cBruch r = sub(k1.r, k2.r);
	cBruch i = sub(k1.i, k2.i);
	return cKompRat(r, i);
}
