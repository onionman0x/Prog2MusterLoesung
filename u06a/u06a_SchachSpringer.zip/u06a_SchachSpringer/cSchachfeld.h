#pragma once

#include <stdbool.h>
#define schachNull (cSchachfeld*)0

class cSchachfeld
{
	int reihe;
	char spalte;
	cSchachfeld* next;

	bool checkZug(char newSpalte, int newReihe);
	bool checkBlockFields(char newSpalte, int newReihe);

	friend bool comparePos(cSchachfeld s1, cSchachfeld s2);

public:
	cSchachfeld(int reihe_in, char spalte_in);
	~cSchachfeld();

	bool springerzug();
	cSchachfeld* getNext();
};

