#include "cSchachfeld.h"
#include <iostream>

#define schachNull (cSchachfeld*)0

using namespace std;

bool cSchachfeld::checkZug(char newSpalte, int newReihe)
{
	int diffSpalte = spalte - newSpalte;
	int diffReihe = reihe - newReihe;
	int completeDif = 0;

	if (diffSpalte < 0)
		diffSpalte *= -1;

	if (diffReihe < 0)
		diffReihe *= -1;

	completeDif = diffReihe + diffSpalte;

	if (completeDif == 3 && (diffReihe > 0 && diffSpalte > 0))
		return true;

	return false;
}

bool cSchachfeld::checkBlockFields(char newSpalte, int newReihe)
{
	char spalte[] = { 'H','E','D','G','F','A' };
	int reihen[] = { 8,8,8,1,3,3 };

	for (int i = 0; i < 6; i++) {
		if (spalte[i] == newSpalte && reihen[i] == newReihe)
			return false;
	}

	return true;
}

cSchachfeld::cSchachfeld(int reihe_in, char spalte_in)
{
	reihe = reihe_in;
	spalte = spalte_in;
	next = schachNull;
}

cSchachfeld::~cSchachfeld()
{
	if (next != schachNull)
		delete next;
	cout << "Destruktor : " << spalte << " " << reihe << endl;
}

bool cSchachfeld::springerzug()
{
	char newSpalte;
	int newReihe;

	cout << "Wohin soll der Laefer springen?" << endl;
	cin >> newSpalte >> newReihe;

	if ((newSpalte >= 'A' && newSpalte <= 'H') && (newReihe >= 1 && newReihe <= 8)) {

		if (checkZug(newSpalte, newReihe) && checkBlockFields(newSpalte, newReihe)) {
			next = new cSchachfeld(newReihe, newSpalte);
			return true;
		}
		else {
			cout << "Ungueltiger Zug" << endl;
		}

	}
	else {
		cout << "Ungueltige Koordinate" << endl;
	}
	return false;
}

cSchachfeld* cSchachfeld::getNext()
{
	return next;
}

bool comparePos(cSchachfeld s1, cSchachfeld s2)
{
	return s1.reihe == s2.reihe && s1.spalte == s2.spalte ? true : false;
}
