#include "cSchachfeld.h"

int main() {

	cSchachfeld* startPos = new cSchachfeld(6, 'E');
	cSchachfeld* zielPos = new cSchachfeld(1, 'C');

	cSchachfeld* aktPos = new cSchachfeld(*startPos);

	while (!comparePos(*aktPos, *zielPos)) {
		if (aktPos->springerzug()) {
			aktPos = aktPos->getNext();
		}
	}

	delete startPos;

	return 0;
}