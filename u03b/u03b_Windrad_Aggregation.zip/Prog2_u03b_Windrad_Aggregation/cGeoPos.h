#pragma once
class cGeoPos {
private:
	double longitude; 
	double latitude; 
public: 
	cGeoPos();			// Universalkonstruktor
	cGeoPos(double long_in, double lat_in);
	void setGeoPos(double long_in, double lat_in);
	double getLong() { return longitude; }
	double getLat() { return latitude; }
	void printGeoPos();
};

