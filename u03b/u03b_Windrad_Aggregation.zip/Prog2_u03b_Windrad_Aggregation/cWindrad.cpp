#include "cWindrad.h"
#include <iostream> 
using namespace std; 

double cWindrad::korrHoehe(double hoehe_in) {
	// Wenn OffShore und groesser als 200m.
	if ((pos.getLong() > 53.5 && pos.getLat() < 6.7) && hoehe_in > 200) 
		return 200.0;
	
	// Wenn OffShore und kleiner als 200m dann bekommt hoehe den originalen Wert.
	if ((pos.getLong() > 53.5 && pos.getLat() < 6.7))
		return hoehe_in;

	// Wenn nicht Offshore und trotzdem groesser als 140m ist.
	if (!(pos.getLong() > 53.5 && pos.getLat() < 6.7) && hoehe_in > 140.0)
		return 140.0;

	
	// Falls nichts davon zutrifft
	return hoehe_in;
}

// Universal
cWindrad::cWindrad() {
	typ = "-";
	hoehe = 140.0;
	leistung = 0;
	pos = cGeoPos(0, 0);
}

// F�r Eingaben
cWindrad::cWindrad(string typ_in, double hoehe_in, double leistung_in, double long_in, double lat_in) {
	typ = typ_in; 
	// hoehe = hoehe_in;	// -> Variable muss hier erst mit einem Wert besetzt werden damit spaeter geprueft werden kann!
	leistung = leistung_in; 
	// Konstruktorenkaskadierung. das Objekt cWindrad::pos bekommt hier die Werte zugewiesen, welches fuer ein cGeoPos Objekt uebergeben werden.
	pos = cGeoPos(long_in, lat_in);
	hoehe = korrHoehe(hoehe_in); // -> Hier findet Wertzuweisung statt, da nunr GeoPos bekannt ist.
	
}

// Standarddestruktor
cWindrad::~cWindrad() {
}


void cWindrad::eingabe() {
	// Tempor�re Variablen und Laengen und Breitengrad neu zu setzen.
	double tmp_long; 
	double tmp_lat;


	cout << "Bitte geben Sie nacheinander die Werte des Windrads ein: " << endl; 
	cout << "Typ: "; 
	// cin >> typ ist true wenn Eingabe erfolgt && ist true wenn Eingabe ein "-" ist
	if (cin >> typ && typ == "-")
		return;
	cout << "Hoehe: "; cin >> hoehe;  
	cout << "Leistung: "; cin >> leistung;  
	cout << "Laengengrad: "; cin >> tmp_long; 
	cout << "Breitengrad: "; cin >> tmp_lat; 

	// ruft Eingabefunktion der Klasse cGeoPos auf und kann somit die Werte neu setzten.
	setGeoPos(tmp_long, tmp_lat);
}

void cWindrad::ausgabe() {
	cout << "Das Windrad " + typ + " ist mit folgenden Werten ausgelegt: " << "\n"
		<< "Hoehe: " << hoehe << "\n"
		<< "Leistung: " << leistung << endl;
	// "Kaskadiert" die Ausgabefunktion.
	pos.printGeoPos();
}
