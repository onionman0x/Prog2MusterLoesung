#include "cGeoPos.h"
#include <iostream>
using namespace std; 

// Universal Konstruktor mit Koordinaten von Worms
cGeoPos::cGeoPos() {
	longitude = 48.79;
	latitude = 8.17; 
}

cGeoPos::cGeoPos(double long_in, double lat_in) {
	longitude = long_in; 
	latitude = lat_in;
}

void cGeoPos::setGeoPos(double long_in,  double lat_in) {

	/*
		Arithmetik:
		Wenn Zahl groe�er als 180 ist: 

		Wenn die Zahl z.B. 1000 ist dann: 
		1000 % 360  = 280  <- Ist die Zahl groe�er als 180 dann muss - 360
		280 - 360 = -80    <- Das ist der Wert der Gesucht wird 

		Wenn kleiner als -180 ist:
		z.B. -1000
		-1000 % 360 = -280 
		-280 + 360 = 80 <- Ergebnis 

		z.B. -1200
		-1200 % 360 = -120  <- Ergebnis 

		Module kann auf doubles mithilfe der Funktion fmod() verwendet werden.
	*/

	longitude = long_in;
	if (longitude > 0)
	{
		longitude = fmod(longitude, 360);
		if (longitude > 180)
		{
			longitude -= 360;
		}
	}
	if (longitude < 0)
	{
		longitude = fmod(longitude, 360);
		if (longitude < -180)
		{
			longitude += 360;
		}
	}
	latitude = lat_in;
	if (latitude > 0)
	{
		latitude = fmod(latitude, 360);
		if (latitude > 180)
		{
			latitude -= 360;
		}
	}
	if (latitude < -180)
	{
		latitude = fmod(latitude, 360);
		if (latitude < -180)
		{
			latitude += 360;
		}
	}
}

// Ausgabefunktion der Klasse cGeoPos.
void cGeoPos::printGeoPos() {
	cout << "Laengengrad: " << longitude << "\n"
		<< "Breitengrad: " << latitude << "\n" << endl;
}


