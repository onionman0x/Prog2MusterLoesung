#pragma once
#include "cGeoPos.h"
#include <iostream>
using namespace std; 


class cWindrad : public cGeoPos {
private:
	string typ;
	double hoehe;
	double leistung;
	// double laenge; 
	// double breite;
	cGeoPos pos;			// Wird Aggregiert, und ersetzt somit die beiden Werte fuer Breiten und Laengengrad
	double korrHoehe(double hoehe_in);

public:
	cWindrad();			// Universalkonstruktor
	cWindrad(string typ_in, double hoehe_in, double leistung_in, double long_in, double lat_in);
	~cWindrad();
	void eingabe();
	void ausgabe();
	// Hilfsmethode, nicht teil der Aufgabe
	string getTyp() { return typ;  }
};

