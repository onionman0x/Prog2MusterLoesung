/*
* Musterloesung: Windrad mit Aggregation u03b
* Name: Luca Chiarelli
* Datum: 13.04.2021
* Beschreibung
* 
*/

#include <iostream>
#include "cWindrad.h"
#define ARRSIZE 1000
using namespace std; 

int main() {
    
	// Aufgabenteil a) 
    cWindrad wr1("Windstrom13", 151.8, 342.0, 48.3, 8.72),
			wr2("Watt4Watt4U", 192.7, 820.0, 57.66, 5.37),
			wr3("Watt4Watt2U", 210, 820.0, 57.66, 5.37),
			wr4;

    wr1.ausgabe();
    wr2.ausgabe();
    wr3.ausgabe();
	wr4.ausgabe();
    
	//##################################################################################################################
	
	
	// Aufgabenteil 2 ohne Pointer

	cWindrad wr[ARRSIZE];
	int i = 0; 
	int hilfzaehler = 0;

	// Eingabeschleife
	cout << "Bitte geben Sie die Daten der Windraeder ohne Pointer ein:" << "\n" << endl;
	for (i; i < ARRSIZE; i++) {
		cout << i + 1 << ". Windrad: " << endl;
		wr[i].eingabe();
		if (wr[i].getTyp() == "-")
			break;
	}
	
	// Falls nicht alle 1000 Windraeder initialisiert werden, wird auch nur soweit ausgegeben, wie vorher initialisiert wurde.
	hilfzaehler = i;

	// Ausgabeschleife
	for (i = 0; i < hilfzaehler; i++) {
		cout << i + 1 << ". Windrad: " << endl;
		wr[i].ausgabe();
	}
	
	
	//#####################################################################################################################
	
	// Aufgabenteil 2 mit Pointer

	cWindrad* wrp = new cWindrad[ARRSIZE];

	// Hier ohne initialisierung, da diese in der for-Schleife stattfindet.
	int j;
	int helpcounter = 0;	// helpcounter wird trotzdem mit 0 vorinitialisiert um Anomalien zu vermeiden.

	// Eingabeschleife
	cout << "Bitte geben Sie die Daten der Windraeder mit Pointer ein:" << "\n" << endl;
	for (j = 0; j < ARRSIZE; j++) {
		cout << j+1 << ". Windrad: " << endl;
		(wrp + j)->eingabe();		// Alternativen: *(wr + i).eingabe() -oder- wr[i].eingabe();
		if ((wr + j)->getTyp() == "-")
			break;
	}

	// Falls nicht alle 1000 Windraeder initialisiert werden, wird auch nur soweit ausgegeben, wie vorher initialisiert wurde.
	int help_counter = j;

	//Ausgabeschleife
	for (j = 0; j < help_counter; j++) {
		cout << j+1 << ". Windrad" << endl;
		(wrp + j)->ausgabe();
	}
	

	// mit new() reservervierten Speicher wieder freigeben
	delete[] wrp;

	return 0;
    
}

