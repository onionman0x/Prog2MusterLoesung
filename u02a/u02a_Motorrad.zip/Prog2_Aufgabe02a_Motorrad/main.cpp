/*
* Name: Luca Chiarelli
* Datum: 06.04.2021
* Programm: Erstellen von Klassen, Klassenattributen, Methoden und der Benutzung im Hauptprogramm
*/

#include <iostream>

// Wird genutzt, um auf den "std::"-Namespace zu erweitern. Objekte und Methoden, welche ein "std::" brauchen, wie z.B. std::cout koennen nun
// ohne Namespace aufgerufen werden.
using namespace std; 

// Aufruf einer Klasse. WICHTIG: eine Klasse muss mit einem ; aehnlich wie bei einem struct beendet werden!!
class Motorrad {
private:
    string bezeichnung;     // Original: std::string
    int raeder;
    int zylinder;
    double antriebsleistung;

public:
    // Universalkonstruktor, welcher die Werte mit "Standardwerten" belegt falls keine Werte mitgegeben werden.
    Motorrad() {
        bezeichnung = "\"--\"";
        raeder = 2;
        zylinder = 1;
        antriebsleistung = 12.3;
    }
    // Dieser Konstruktor hat Parameter, welche den Attributen in einer Klasse �bergeben werden k�nnen.
    Motorrad(string bezeichnung, int raeder_in, int zylinder_in, double antrieb_in) {
        
        /* 
        * "this" ist ein Zeiger, welcher auf das Objekt zeigt, das diese Methode aufruft. 
        * Da wir bezeichnung hier als Attribut in der Klasse, sowohl auch als Parameter des Konstruktors haben, wuerde Visual Studio hier nicht unterscheiden koennen,
        * welche "bezeichnung" wir ansprechen. Durch benutzung des "this"-Zeiger koennen wir das hiermit aber genau unterscheiden.
        * 
        * this->bezeichung zeigt hier auf std::string Motorrad::bezeichnung, welches das Attribut der Klasse Motorrad definiert. 
        * faehrt man mit der Maus ueber das bezeichnung, so zeigt Visual Studio die zugehoerigkeit der Variable.
        * 
        * bezeichung verweist hier nur auf ein std::string bezeichnung, welches nicht der Klasse Motorrad angehoert.
        */
        this->bezeichnung = bezeichnung;
        /*
        * Alternativ: bezeichnung = bezeichnung:in
        */
       
        raeder = raeder_in;
        zylinder = zylinder_in;
        antriebsleistung = antrieb_in;
    }
    // Ausgabefunktion um die Attribute dieser Klasse formatiert auszugeben.
    void ausgabe() {
        std::cout << "Bezeichnung/Typ:\t" << bezeichnung
            << "\nAnzahl Raeder:\t\t" << raeder
            << "\nAnzahl Zylinder:\t" << zylinder
            << "\nAntriebsleistung:\t" << antriebsleistung
            << "\n" << endl;
    }


};      // <-- Ende der Klasse mit einem Semikolon!

int main() {

    // "Instanziierung eines Objekts" in der Hauptfunkion.
    // Dieses Objekt bekommt ueber die Klammern Werte zugewiesen.
    Motorrad suzuki("Hayabusa", 2, 4, 450.0);  
    
    
    // Dieses Objekt bekommt keine Werte ueber die Klammern zugewiesen und greift somit auf den Standard zurueck.  
    Motorrad standard;                       
    
    /*
    * Instanziierung eines Objekt mittels eines Pointers, mit new() wird hier nun Speicher fuer genau 1 Objekt von
    * Typ Motorrad reserviert. Objekte, die mit new() Speicher zugewiesen bekommen, muessen mit delete() wieder freigegeben werden.
    */
    Motorrad * scooter= new Motorrad(); // -> Hier greift der Universalkonstruktor.
    Motorrad * HD = new Motorrad("FourtyEight", 2, 3, 280.0); // -> Hier werden die Werte beim Aufruf des Klassentyps uebergeben.

    // Aufruf der Klassenmethode ausgabe(). Auf die Methode wird mittels '.' zugegriffen.
    suzuki.ausgabe(); 
    standard.ausgabe(); 
    // Da bei diesen Objekten ein Pointer genutzt wurde, muss hier mittels des '->' Operators auf die Methode zugegriffen werden.
    scooter->ausgabe();
    // Alternative:
    (*HD).ausgabe();

    // Der fuer die Pointer reservierte Speicher muss hier nun wieder freigegeben werden.
    // Der Aufruf der delete() Funktion erfolgt allerdings normalerweise im Destruktor, welcher in den laufenden Vorlesungen noch vorkommen wird.
    delete scooter;
    delete HD; 
    return 0;
}
