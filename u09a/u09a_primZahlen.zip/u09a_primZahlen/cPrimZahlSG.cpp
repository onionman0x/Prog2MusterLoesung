#include "cPrimZahlSG.h"
#include <iostream>

using namespace std;

bool cPrimZahlSG::is_prime(int n)
{
	int i; 
	for (i = 2; i <= n / 2; i++) 
	{ 
		if (n % i)
			continue; 
		else
			return false; 
	}
	return true;
}

int cPrimZahlSG::nextSGPrim(int n)
{
	n = n + 1;
	while (!is_prime(n) || !is_prime(2 * (n) + 1)) {
		n++;
	}
	return n;
}

int cPrimZahlSG::prevSGPrim(int n)
{
	n = n - 1;
	while (!is_prime(n) || !is_prime(2 * (n) + 1)) {
		n--;
	}
	return n;
}

cPrimZahlSG::cPrimZahlSG(int p_in)
{
	p_in = nextSGPrim(p_in);
	while (p_in > maxprim) {
		p_in = prevSGPrim(p_in);
	}
	p = p_in;
}

cPrimZahlSG cPrimZahlSG::operator++(int n)
{
	p = nextSGPrim(p);
	while (p > maxprim) {
		p = prevSGPrim(p);
	}
	return *this;
}

cPrimZahlSG cPrimZahlSG::operator--(int n)
{
	p = prevSGPrim(p);
	while (p < 1) {
		p = nextSGPrim(p);
	}
	return *this;
}

int& cPrimZahlSG::operator[](int n)
{
	int i = 1;
	int c = 0;

	if (n < 0) {
		n = 0;
		while (c < 20) {
			i = nextSGPrim(i);
			std::cout << i << std::endl;
			c++;
		}
	}
	else {
		n = nextSGPrim(n);
		while (n > maxprim) {
			n = prevSGPrim(n);
		}
	}
	return n;
}

ostream& operator<<(ostream& o, const cPrimZahlSG p)
{
	o << "Primzahl: " << p.p << endl;
	return o;
}
