#pragma once
#define maxprim 10000

#include <iostream>

using namespace std;

class cPrimZahlSG
{
	int p;
	bool is_prime(int n);
	int nextSGPrim(int n);
	int prevSGPrim(int n);

public:
	cPrimZahlSG(int p_in = 1);
	cPrimZahlSG operator ++ (int n);
	cPrimZahlSG operator -- (int n);
	int& operator [] (int n);

	friend ostream& operator << (ostream& o, const cPrimZahlSG p);
};

