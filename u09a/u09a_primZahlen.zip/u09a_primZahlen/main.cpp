#include "cPrimZahlSG.h"
#include <iostream>

using namespace std;

int main(){

	char c = '0';
	int i = 0;
	cPrimZahlSG pz;

	while (c != 'e') {
		cout << "Waehle eine Operation : ";
		cin >> c;

		switch (c) {
		case '+' :
			pz++;
			cout << pz;
			break;
		case '-' :
			pz--;
			cout << pz;
			break;
		case 's':
			cout << "Gebe einen Index an: ";
			cin >> i;
			i = pz[i];
			cout << pz << endl << "index primzahl: " << i << endl;
			break;
		case 'e':
			cout << "Programm wird beendet" << endl;
			break;
		default:
			cout << "falsches Zeichen";
			break;
		}
	}

	return 0;
}