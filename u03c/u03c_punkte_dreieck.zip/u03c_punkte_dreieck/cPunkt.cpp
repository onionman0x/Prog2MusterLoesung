#include "cPunkt.h"
#include <iostream>

/* Konstruktor von cPunkt, werden Werte mitgegeben die gr��er 10 oder kleiner -10 sind
werden diese entsprechend umgerechnet */
cPunkt::cPunkt(double x_in, double y_in)
{
	if (x_in > 10) {
		x = 10;
	}
	else if (x_in < -10) {
		x = -10;
	}
	else {
		x = x_in;
	}

	if (y_in > 10) {
		y = 10;
	}
	else if (y_in < -10) {
		y = -10;
	}
	else {
		y = y_in;
	}
}

/* Ausgabe der beiden Koordinaten */
void cPunkt::ausgabe()
{
	std::cout << "X : " << x << std::endl;
	std::cout << "Y : " << y << std::endl;
}

/* gibt y zur�ck */
double cPunkt::getY()
{
	return y;
}

/* gibt x zur�ck */
double cPunkt::getX()
{
	return x;
}
