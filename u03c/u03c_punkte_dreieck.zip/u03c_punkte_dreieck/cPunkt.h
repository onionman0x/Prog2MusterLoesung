#pragma once
/* Klasse die einen Punkt in einem Koordinatensystem beschreibt, besitzt eine x und y koordinate*/
class cPunkt
{
	double x;
	double y;

public:
	cPunkt(double x_in = 0, double y_in = 0);
	void ausgabe();
	double getY();
	double getX();
};

