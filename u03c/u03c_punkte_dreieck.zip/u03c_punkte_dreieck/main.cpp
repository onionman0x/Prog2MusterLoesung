#include "cPunkt.h"
#include "cDreieck.h"

int main() {

	cPunkt a = cPunkt(11.7, 2.41);
	cPunkt b = cPunkt(1.24, -13.8);
	cPunkt c = cPunkt(-9.73, 3.42);

	cDreieck d = cDreieck(a, b, c);
	d.ausgabe();

	return 0;
}