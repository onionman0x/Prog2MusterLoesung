#pragma once
#include "cPunkt.h"

/* Klasse zur Darstellung eines Dreiecks, besitzt 3 Attribute vom Typ cPunkt die das Dreieck beschreiben*/

class cDreieck
{
	cPunkt a;
	cPunkt b;
	cPunkt c;
	double strecke(cPunkt a, cPunkt b);

public:
	cDreieck(cPunkt a_in = cPunkt(0.0, 1.0), cPunkt b_in = cPunkt(1.0, 0.0), cPunkt c_in = cPunkt(0.0, 0.0));
	double umfangD();
	double flaecheD();
	void ausgabe();
};

