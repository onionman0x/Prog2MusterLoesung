#include "cDreieck.h"
#include <cmath>
#include <iostream>

/* Berechnet die Strecke zwischen den Punkten a und b, um die Wurzel zu ziehen wird Mathefunktion "sqrt" verwendet, 
 f�r Potenzen "pow" */
double cDreieck::strecke(cPunkt a, cPunkt b)
{
	return sqrt(pow((b.getX() - a.getX()), 2) + pow((b.getY() - a.getY()), 2));
}

/* Konstruktor */
cDreieck::cDreieck(cPunkt a_in, cPunkt b_in, cPunkt c_in)
{
	a = a_in;
	b = b_in;
	c = c_in;
}

/* Berechnet den Umfang vom Dreieck, verwendet daf�r die private Methode "strecke" */
double cDreieck::umfangD()
{
	return (strecke(a, b) + strecke(b, c) + strecke(c, a));
}

/*Berechnet den Flaecheninhalt vom Dreieck, verwendet daf�r die private Methode "streck" 
 und die Mathefunktion "sqrt" */
double cDreieck::flaecheD()
{
	double s = umfangD() / 2;
	return sqrt(s * (s - strecke(a, b)) * (s - strecke(b, c)) * (s - strecke(c, a)));
}

/* Gibt zun�chst die 3 Punkte, Umfang vom Dreieck und Flaecheninhalt des Dreiecks aus, daf�r die "ausgabe" Funktion von cPunkt verwendet */
void cDreieck::ausgabe()
{
	a.ausgabe();
	b.ausgabe();
	c.ausgabe();

	std::cout << "Umfang: " << umfangD() << std::endl;
	std::cout << "Flaecheninhalt: " << flaecheD() << std::endl;
}
