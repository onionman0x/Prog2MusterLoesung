#pragma once
/* Basisklasse cFahrzeug */
class cFahrzeug
{
	int anzahlSitze;

public:
	cFahrzeug(int sitze_in = 4);
	int nenneSitze();
};

