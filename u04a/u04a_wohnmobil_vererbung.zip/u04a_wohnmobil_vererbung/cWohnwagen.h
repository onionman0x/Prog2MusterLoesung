#pragma once
#include "cFahrzeug.h"
#include "cWohnung.h"
/* erbt von cFahrzeug und cWohnung */
class cWohnwagen : public cFahrzeug, public cWohnung
{
	double zugLast;
public:
	cWohnwagen(double zugLast_in = 0.73, int betten_in = 1, int sitze_in = 0);
	double nenneZuglast();
	void leereBriefKasten();
};

