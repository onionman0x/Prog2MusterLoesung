#include "cWohnung.h"
#include <iostream>

cWohnung::cWohnung(int betten_in)
{
	anzahlBetten = betten_in;
}

int cWohnung::nenneBetten()
{
	return anzahlBetten;
}

void cWohnung::leereBriefKasten()
{
	std::cout << "Die Post ist da." << std::endl;
}
