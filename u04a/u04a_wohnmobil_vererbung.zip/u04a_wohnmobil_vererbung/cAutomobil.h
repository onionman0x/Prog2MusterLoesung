#pragma once
#include "cWohnwagen.h"
#include "cFahrzeug.h"
/* Klasse cAutomobil, erbt von cFahrzeug */
class cAutomobil : public cFahrzeug
{
	double zugKraft;

public:
	cAutomobil(double zugKraft_in = 1.2, int sitze_in = 5);
	bool ziehen(cWohnwagen w);
};

