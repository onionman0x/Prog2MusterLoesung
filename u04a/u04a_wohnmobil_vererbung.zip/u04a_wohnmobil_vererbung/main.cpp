#include "cAutomobil.h"
#include "cWohnwagen.h"
#include "cAppartement.h"
#include "cWohnmobil.h"
#include <iostream>

using namespace std;

int main() {

	cAutomobil Admiral; 
	cWohnwagen Zugvogel; 
	cAppartement SweetHome(8); 
	cWohnmobil MobilHome(6, 6);

	cout << "Auto zieht Wohnwagen ?      (0/1): " << Admiral.ziehen(Zugvogel) << endl; 
	cout << "Wohnmobil zieht Wohnwagen ? (0/1): " << MobilHome.ziehen(Zugvogel) << endl << endl; 
	cout << "Sitzezahl Admiral: " << Admiral.nenneSitze() << endl; 
	cout << "Bettenzahl Zugvogel: " << Zugvogel.nenneBetten() << endl; 
	cout << "Sitzezahl MobilHome: " << MobilHome.cAutomobil::nenneSitze() << endl; 
	cout << "Ausstattung MobilHome: "; MobilHome.ausgabeSitzeBetten(); 
	cout << "Briefkasten MobilHome: "; MobilHome.leereBriefKasten(); 
	cout << "Briefkasten SweetHome: "; SweetHome.leereBriefKasten(); 
	cout << "Das SweetHome hat " << SweetHome.nenneBetten() << " Betten." << endl << endl; 
	cout << " *** ENDE *** " << endl << endl;

	return 0;
}