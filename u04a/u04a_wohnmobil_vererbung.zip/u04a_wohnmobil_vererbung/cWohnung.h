#pragma once
/*Basisklasse cWohnung*/
class cWohnung
{
	int anzahlBetten;

public:
	cWohnung(int betten_in = 3);
	int nenneBetten();
	void leereBriefKasten();
};

