#include "cFahrzeug.h"

cFahrzeug::cFahrzeug(int sitze_in)
{
	anzahlSitze = sitze_in;
}

int cFahrzeug::nenneSitze()
{
	return anzahlSitze;
}
