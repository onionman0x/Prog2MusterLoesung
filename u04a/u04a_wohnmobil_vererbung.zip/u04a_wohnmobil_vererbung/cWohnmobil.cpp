#include "cWohnmobil.h"
#include <iostream>

/* Konstruktorenkaskade, setzt Werte der Basisklasse und instanziert diese */
cWohnmobil::cWohnmobil(int sitze_in, int betten_in, double zugKraft_in, double zugLast_in) : cAutomobil(zugKraft_in, sitze_in) , cWohnwagen(betten_in, betten_in, sitze_in)
{
}

/* Gibt die notwendigen Werte aus */
void cWohnmobil::ausgabeSitzeBetten()
{
	std::cout << "Sitze : " << cAutomobil::nenneSitze();
	std::cout << ", Betten: " << cWohnwagen::nenneBetten() << std::endl;
}
