#include "cAppartement.h"

/* Konstruktorenkaskade, setzt Werte der Basisklasse und instanziert diese */
cAppartement::cAppartement(int betten_in) : cWohnung(betten_in)
{
}
