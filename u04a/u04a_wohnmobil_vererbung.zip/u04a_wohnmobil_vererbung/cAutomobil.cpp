#include "cAutomobil.h"

/* Konstruktorenkaskade, setzt Werte der Basisklasse und instanziert diese */
cAutomobil::cAutomobil(double zugKraft_in, int sitze_in) : cFahrzeug(sitze_in)
{
	zugKraft = zugKraft_in;
}

/* �berpr�ft ob die zugkraft gr��er ist als die Zuglast des mitgegebenen Objects 
 von Typ cWohnwagen */
bool cAutomobil::ziehen(cWohnwagen w)
{
	return zugKraft > w.nenneZuglast();
}
