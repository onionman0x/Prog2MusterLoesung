#pragma once
#include "cWohnung.h"
class cAppartement : public cWohnung
{
public:
	cAppartement(int betten_in = 4);
};

