#pragma once
#include "cAutomobil.h"
#include "cWohnwagen.h"
class cWohnmobil : public cAutomobil, public cWohnwagen
{
public:
	cWohnmobil(int sitze_in = 3, int betten_in = 2, double zugKraft_in = 0.7, double zugLast_in = 0.0);
	void ausgabeSitzeBetten();
};

