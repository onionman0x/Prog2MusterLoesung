#include "cWohnwagen.h"
#include <iostream>

/* Konstruktorenkaskade, setzt Werte der Basisklasse und instanziert diese */
cWohnwagen::cWohnwagen(double zugLast_in, int betten_in, int sitze_in) : cFahrzeug(sitze_in), cWohnung(betten_in)
{
	zugLast = zugLast_in;
}

double cWohnwagen::nenneZuglast()
{
	return zugLast;
}

void cWohnwagen::leereBriefKasten()
{
	std::cout << "Keine Post, nur postlagernd" << std::endl;
}
