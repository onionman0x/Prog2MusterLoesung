#include <iostream>
#include "cText.h"

using namespace std;

int main() {
    cText spielText("Rohtext", "data");

    spielText.ausgabe();

    spielText.aendereBezeichnung("Gedicht");

    spielText.ersetzeZeile(5, "als fuenftes ist‘s mir einerlei");

    spielText.ausgabe();

    cText machsBesser("machsBesser", "data1");

    machsBesser.ausgabe();

    cText cloneText(machsBesser);

    cloneText.ausgabe();

    cloneText = spielText;

    cloneText.ausgabe();

    return 0;
}