#include <iostream>

using namespace std;

class cLine
{
private:
    string zeile;
    cLine *prev;

public:
    cLine(string zeile_in, cLine *prev_in);
    cLine(const cLine &obj);
    ~cLine();

    cLine* getPrev() const;
    string getLine() const;
    void setLine(string line_in);
    cLine* getNfromThis(int n, int *summ, int i);
    cLine* addElem(string zeile_in);
    void ausgabeLine();
};