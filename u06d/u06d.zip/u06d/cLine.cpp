#include "cLine.h"

cLine::cLine(string zeile_in, cLine *prev_in) {
    zeile = zeile_in;
    prev = prev_in;
}

cLine::cLine(const cLine &obj) {
    zeile = obj.getLine();

    if (obj.getPrev()) {
        prev = new cLine(*obj.getPrev());
    }
}

cLine::~cLine() {
    if (prev) {
        delete(prev);
    }
}

cLine* cLine::getPrev() const{
    return prev;
}

string cLine::getLine() const{
    return zeile;
}

void cLine::setLine(string line_in) {
    zeile = line_in;
}

cLine* cLine::getNfromThis(int n, int *summ, int i) {
    *summ += 1;

    if(!prev) {
        if (*summ - n == i) {
            return this;
        }
        return nullptr;
    }

    cLine *res = prev->getNfromThis(n, summ, i+1);

    if(!res) {
        if (*summ - n == i) {
            return this;
        }
        return nullptr;
    }

    return res;
}

cLine* cLine::addElem(string zeile_in) {
    return new cLine(zeile_in, this);
}

void cLine::ausgabeLine() {
    if (prev) {
        prev->ausgabeLine();
    }

    cout << zeile << endl;
}