#include <iostream>
#include <fstream>
#include "cLine.h"

using namespace std;

class cText
{
private:
    string bezeichnung;
    cLine *text;

    cLine* parce_file(string filename);

public:
    cText(string bezeichnung_in, string filename);
    cText(const cText &obj);
    ~cText();

    void ausgabe();
    void ersetzeZeile(int num, string neuText);
    void aendereBezeichnung(string neuBez);
    cText operator= (const cText &obj);
};