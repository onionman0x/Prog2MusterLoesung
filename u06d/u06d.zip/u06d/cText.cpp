#include "cText.h"

cLine* cText::parce_file(string filename) {
    string line;

    ifstream in_file(filename);

    getline (in_file, line);
    cLine *curr = new cLine(line, nullptr);

    while (getline (in_file, line))
    {
        curr = curr->addElem(line);
    }
    
    in_file.close();

    return curr;
}

cText::cText(const cText &obj) {
    bezeichnung = obj.bezeichnung;
    text = new cLine(*obj.text);
}

cText::cText(string bezeichnung_in, string filename){
    bezeichnung = bezeichnung_in;
    text = parce_file(filename);
}

cText::~cText() {
    if (text) {
        delete text;
    }
}

void cText::ausgabe() {
    cout << "Bezeichnung: " << bezeichnung << endl;

    text->ausgabeLine();

    cout << endl;
}

void cText::ersetzeZeile(int num, string neuText) {
    int summ = 0;

    cLine *n_elem = text->getNfromThis(num, &summ, 0);

    n_elem->setLine(neuText);
}

void cText::aendereBezeichnung(string neuBez) {
    bezeichnung = neuBez;
}

cText cText::operator = (const cText &obj) {
    if (this != &obj) {
        bezeichnung = obj.bezeichnung;
        text = new cLine(*obj.text);
    }

    return *this;
}