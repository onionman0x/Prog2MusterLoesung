/*
* Name: Luca Chiarelli
* Datum: 06.04.2021
* Beschreibung: Programm zur Klassenerstellung und Einteilung in "Module". 
                Verwaltung von Windraeder, welches Daten einlesen und automatisch korrigieren kann.
* 
*/

#include <iostream>
#include "cWindrad.h"
#define ARRSIZE 1000

using namespace std;

int main()
{
    // Aufgabenteile 1
    cWindrad wr1("Windstrom13", 131.8, 320.0, 48.3, 8.72), 
            wr2("Watt4Watt78", 192.7, 730.0, 56.76, 5.8),   // Dieses Windrad ist OffShore 
            wr3;

    wr1.ausgabe();
    wr2.ausgabe();
    wr3.ausgabe();


    // #####################################################################################################################################
    // Aufgabenteil 2 


    cWindrad wr[ARRSIZE];

    int i = 0;  // Laufsvariable fuer for-Schleife
    int hilfszaehler = 0;   // Hilfszaehler, mit 0 vorinitialisiert um Anomalien zu vermeiden.

    // Eingabe der Windraeder
    cout << "Eingabe der Windraeder ohne Pointer: " << endl;
    for (i; i < ARRSIZE; i++) {
        cout << i + 1 << ". Windrad:" << endl;
        wr[i].eingabe();
        
        if (wr[i].getTyp() == "-")
            break;
    }

    // Falls die Schleife vor erreichen der 1000 abgebrochen werden sollte, so bekommt hilfszaehler hier den Wert von i.
    // i wird fuer die naechste for-Schleife wieder auf 0 gesetzt und soll solange laufen, wie zuletzt werde initialisiert worden sind.
    hilfszaehler = i;

    // Ausgabe der Windraeder
    cout << "\n" << "Ausgabe der eingelesenen Windraeder: " << endl;
    for (i = 0; i < hilfszaehler; i++) {
        cout << i + 1 << endl;  
        wr[i].ausgabe();
    }


    // #####################################################################################################################################

    // Aufgabenteil 2 nochmal mit Pointer
    cWindrad* wrp = new cWindrad[1000];

    int j = 0;
    int helpcounter = 0;

    // Eingabe der Windraeder
    cout << "Eingabe der Windraeder mit Pointer: " << endl;
    for (j; j < ARRSIZE; j++) {
        cout << j + 1 << ". Windrad:" << endl;
        (wrp+j)->eingabe();

        if ((wrp+j)->getTyp() == "-")
            break;
    }

    // Falls die Schleife vor erreichen der 1000 abgebrochen werden sollte, so bekommt hilfszaehler hier den Wert von i.
    // i wird fuer die naechste for-Schleife wieder auf 0 gesetzt und soll solange laufen, wie zuletzt werde initialisiert worden sind.
    helpcounter = j;

    // Ausgabe der Windraeder
    cout << "\n" << "Ausgabe der eingelesenen Windraeder: " << endl;
    for (j = 0; j < helpcounter; j++) {
        cout << j + 1 << endl;
        (wrp+j)->ausgabe();
    }

    // reservierten Speicher wieder freigeben.
    delete[] wrp;

    return 0;
}
