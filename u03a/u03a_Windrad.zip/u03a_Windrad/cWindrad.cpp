#include "cWindrad.h"

double cWindrad::korrHoehe(double hoehe_in)
{
	if ((laenge > 53.5 && breite < 6.7) && hoehe_in > 200.0)
		// Automatische Korrektur auf 200
		return 200;

	if (laenge > 53.5 && breite < 6.7)
		// Falls es ein OffShore Windrad ist und kleiner als 200m ist, darf es seine groesse behalten.
		return hoehe_in;


	if (!(laenge > 53.5 && breite < 6.7) && hoehe_in > 140.0)
		// Ist das Windrad nicht OffShore und trotzdem groesser als 140m, so muss es korrigiert werden.
		return 140.0;

	// Falls keine der If Abfragen zutreffen.
	return hoehe_in;
}

cWindrad::cWindrad() {
	typ = "\"--\"";
	hoehe = 130.0; 
	leistung = 0.0;
	laenge = 0.0;
	breite = 0.0;
}

cWindrad::cWindrad(string typ_in, double hoehe_in, double leistung_in, double laenge_in, double breite_in) {
	typ = typ_in; 
	// Hier erfolgt keine Zuweisung der Hoehe, da zuerst der Laengen- und Breitengrad bekannt sein muessen.
	leistung = leistung_in; 
	laenge = laenge_in;
	breite = breite_in; 
	// Zuweisung erfolgt hier bereits mit korrigierten Werten.
	hoehe = korrHoehe(hoehe_in);
}

// Standard Destruktor
cWindrad::~cWindrad()
{
}

void cWindrad::eingabe() {
	cout << "Typ: "; 
	// Hier erfolgt gleichzeitig eine Eingabe und eine Ueberpruefung.
	// War die Eingabe ein '-', so wird die Funktion eingabe() direkt abgebrochen.
	if (cin >> typ && typ == "-")
		return;
	cout << "Hoehe: "; cin >> hoehe;
	cout << "Leistung: "; cin >> leistung; 
	cout << "Laengengrad: "; cin >> laenge;
	cout << "Breitengrad: "; cin >> breite;
}

// Formatierte Ausgabe der Klasse cWindrad.
void cWindrad::ausgabe() {
	cout << "Das Windrad \"" + typ + "\" bezistzt folgende Werte: " << endl;
	cout << "Typ: " << typ << "\n"
		<< "Hoehe: " << hoehe << "\n"
		<< "Leistung: " << leistung << "\n"
		<< "Laengengrad: " << laenge << "\n"
		<< "Breitengrad: " << breite << "\n" << endl;
}
