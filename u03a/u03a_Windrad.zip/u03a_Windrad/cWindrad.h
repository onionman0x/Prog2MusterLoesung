#pragma once
// Wird fuer string gebraucht.
#include <iostream>
// Namespace std ergaenzen
using namespace std;

class cWindrad {
private:
	string typ;
	double hoehe; 
	double leistung; 
	double laenge; 
	double breite;
	// Private Methode, funktioniert nur innerhalb der Klasse und kann aus dem Hauptprogramm heraus nicht genutzt werden.
	double korrHoehe(double hoehe_in);	
public: 
	cWindrad();	// Universalkonstruktor
	cWindrad(string typ_in, double hoehe_in, double leistung_in, double laenge_in, double breite_in);
	~cWindrad();// Standarddestruktor
	void eingabe();
	void ausgabe();
	// Getter, welcher bereits Inline definiert wurde da es sich nur um einen kleinen Aufruf handelt.
	string getTyp() { return typ; }	
};

