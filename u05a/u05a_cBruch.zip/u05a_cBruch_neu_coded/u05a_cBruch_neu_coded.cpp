/**
* Name: Luca Chiarelli
* Datum: 27.04.2021
* Beschreibung: Brueche verwerten
*
*/
#include <iostream>
#include "cBruch.h"

using namespace std;

// Arithmetiken, Formeln stehen auf dem Aufgabenblatt u05a
cBruch add(cBruch a, cBruch b) {
    cBruch c; 
    c.zaehler = (a.zaehler * b.nenner) + (b.zaehler * a.nenner);
    c.nenner = a.nenner * b.nenner;
	
    return c;
}

cBruch subt(cBruch a, cBruch b) {
	cBruch c;
	c.nenner = a.nenner * b.nenner;
	c.zaehler = (a.zaehler * b.nenner) - (b.zaehler * a.nenner);
	
	return c;
}

cBruch mul(cBruch a, cBruch b) {
	cBruch c;
	c.nenner = a.nenner * b.nenner;
	c.zaehler = a.zaehler * b.zaehler;

	return c;
}

cBruch div(cBruch a, cBruch b) {
	cBruch c;
	c.nenner = a.nenner * b.zaehler;
	c.zaehler = a.zaehler * b.nenner;

	return c;
}

// Vergleicht Brueche indem diese als Gleitkommazahl umgerechnet wird und anschliessend auf die Grosse verglichen wird
int vergleich(cBruch a, cBruch b) {

	double help1 = (double)a.zaehler / (double)a.nenner; 
	double help2 = (double)b.zaehler / (double)b.nenner; 

	// Hilfsausgabe
	cout << "a = " << help1 << endl;
	cout << "b = " << help2 << endl;

	if (help1 < help2)
		return -1;
	if (help1 == help2)
		return 0; 
	if (help1 > help2)
		return 1;
}


int main() {
    
	cBruch cBArr[8] = {
		cBruch(3, 4), cBruch(2, 3),
		cBruch(4, -24), cBruch(-7, 9),
		cBruch(-5, -3), cBruch(-14, 22),
		cBruch(25, 12), cBruch(3, 5)
	};

	// Aufgabenteil 1 - Ausgaben
	cout << "Aufgabenteil 1 - Ausgaben: " << endl;
	for (int i = 0; i < 8; i++) {
		cout << i + 1 << ". " << endl; cBArr[i].ausgabe();
	}

	// Aufgabenteil 2 - Rechnen
	cout << "Aufgabenteil 2 - Berechnung:" << endl;
	cout << "\n\n\nAddition: " << endl;
	cBruch summe = add(cBArr[0], cBArr[1]);
	summe.ausgabe();

	cout << "Subtraktion" << endl;
	cBruch differenz = subt(cBArr[2], cBArr[3]);
	differenz.ausgabe();

	cout << "Multiplizieren: " << endl;
	cBruch produkt = mul(cBArr[4], cBArr[5]);
	produkt.ausgabe();

	cout << "Dividieren: " << endl;
	cBruch quotienten = div(cBArr[6], cBArr[7]);
	quotienten.ausgabe();

	// Aufgabenteil 3 - vergleichen
	cout << "Aufgabenteil 3 - vergleichen: " << endl;

	for (int i = 0; i < 7; i++) {
		// Vergleich nur Bruch 1 mit 3, 2 mit 4, 5 mit 7 und 6 mit 8
		if (i != 2 && i != 3) {
			// Switch Case um fuer die Returnwerte der vergleich()-Funktion eine Ausgabe machen zu koennen.
			switch (vergleich(cBArr[i], cBArr[i + 2])) {
			case -1:
				cout << "a < b" << endl;
				break;
			case 0:
				cout << "a == b" << endl;
				break;
			case 1:
				cout << "a > b" << endl;
				break;
			}
		}
	}

	return 0;
}
