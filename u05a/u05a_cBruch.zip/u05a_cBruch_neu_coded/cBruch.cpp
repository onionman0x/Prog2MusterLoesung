#include "cBruch.h"
#include <iostream> 

using namespace std;

void cBruch::kuerzen() {
	int help = zaehler; 
	zaehler /= ggt(zaehler, nenner); 
	nenner /= ggt(help, nenner);
}

// Rekursiv modulo rechnen bis die 0 erreicht wird, dann wird der Wert zurueckgegeben.
int cBruch::ggt(int zaehler, int nenner) {

	if (nenner == 0)
		return zaehler; 
	return ggt(nenner, zaehler % nenner);
}

// Konstruktor welcher direkt die Negativbrueche korrigiert
cBruch::cBruch(int zaehler_in, int nenner_in) : zaehler(zaehler_in), nenner(nenner_in) {
	posKorr();
}

void cBruch::ausgabe() {
	cout << "ungekuerzt: " << zaehler << " / " << nenner  << " = " << (double)zaehler / (double)nenner << endl;
	kuerzen(); 
	posKorr();
	cout << "gekuerzt: " << zaehler << " / " << nenner << " = " << (double)zaehler / (double)nenner << endl;
}

// Wenn kleiner als 0 dann multipliziere Bruch mit -1, wenn Nenner 0 ist wird auf 1 korrigiert
void cBruch::posKorr() {
	if (nenner < 0) {
		zaehler *= -1; 
		nenner *= -1;
	}

	if (nenner == 0)
		nenner = 1;
}


