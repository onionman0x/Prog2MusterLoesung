#pragma once
class cBruch {
private: 
	int zaehler; 
	int nenner; 
	void kuerzen(); 
	int ggt(int zaehler, int nenner);

public: 
	cBruch(int zaehler_in = 0, int nenner_in = 0);
	void ausgabe();
	void posKorr();
	friend cBruch add(cBruch a, cBruch b);
	friend cBruch subt(cBruch a, cBruch b);
	friend cBruch mul(cBruch a, cBruch b);
	friend cBruch div(cBruch a, cBruch b);
	friend int vergleich(cBruch a, cBruch b);
};

